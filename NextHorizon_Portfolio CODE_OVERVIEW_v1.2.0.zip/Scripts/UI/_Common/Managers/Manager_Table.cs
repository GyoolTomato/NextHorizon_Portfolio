﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

public class Manager_Table : Singleton<Manager_Table>
{
    //
    Dictionary<EItemType, _101_Items.Values> _dic_Items = new Dictionary<EItemType, _101_Items.Values>();
    Dictionary<int, _107_CharacterLevel.Values> _dic_Level_CharacterLevel = new Dictionary<int, _107_CharacterLevel.Values>();
    Dictionary<int, _108_PlayerLevel.Values> _dic_Level_PlayerLevel = new Dictionary<int, _108_PlayerLevel.Values>();
    Dictionary<int, _111_WeaponLevel.Values> _dic_Level_WeaponLevel = new Dictionary<int, _111_WeaponLevel.Values>();
    Dictionary<int, _112_ArmorLevel.Values> _dic_Level_ArmorLevel = new Dictionary<int, _112_ArmorLevel.Values>();


    /// <summary>
    /// 
    /// </summary>
    public void Init()
    {
        //
        _dic_Items.Clear();

        foreach (var item in _101_Items.GetList())
        {
            //
            if (_dic_Items.ContainsKey(item.type))
            {
                Debug.LogError($"Manager_Table::Init() - Duplicate type key found: {item.type}");
                continue;
            }

            //
            _dic_Items.Add(item.type, item);
        }

        //
        _dic_Level_CharacterLevel.Clear();

        foreach (var item in _107_CharacterLevel.GetList())
        {
            //
            if (_dic_Level_CharacterLevel.ContainsKey(item.level))
            {
                Debug.LogError($"Manager_Table::Init() - Duplicate level key found: {item.level}");
                continue;
            }

            //
            _dic_Level_CharacterLevel.Add(item.level, item);
        }

        //
        _dic_Level_PlayerLevel.Clear();

        foreach (var item in _108_PlayerLevel.GetList())
        {
            //
            if (_dic_Level_PlayerLevel.ContainsKey(item.level))
            {
                Debug.LogError($"Manager_Table::Init() - Duplicate level key found: {item.level}");
                continue;
            }

            //
            _dic_Level_PlayerLevel.Add(item.level, item);
        }

        //
        _dic_Level_WeaponLevel.Clear();

        foreach (var item in _111_WeaponLevel.GetList())
        {
            //
            if (_dic_Level_WeaponLevel.ContainsKey(item.level))
            {
                Debug.LogError($"Manager_Table::Init() - Duplicate level key found: {item.level}");
                continue;
            }

            //
            _dic_Level_WeaponLevel.Add(item.level, item);
        }

        //
        _dic_Level_ArmorLevel.Clear();

        foreach (var item in _112_ArmorLevel.GetList())
        {
            //
            if (_dic_Level_ArmorLevel.ContainsKey(item.level))
            {
                Debug.LogError($"Manager_Table::Init() - Duplicate level key found: {item.level}");
                continue;
            }

            //
            _dic_Level_ArmorLevel.Add(item.level, item);
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="type"></param>
    /// <returns></returns>
    public _101_Items.Values GetItemInfo(EItemType type)
    {
        if (_dic_Items.ContainsKey(type))
        {
            return _dic_Items[type];
        }
        else
        {
            Debug.LogError($"Manager_Table::GetItemInfo() - Type info not found for type: {type}");
            return null;
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="level"></param>
    /// <returns></returns>
    public _107_CharacterLevel.Values GetCharacterLevelInfo(int level)
    {
        if (_dic_Level_CharacterLevel.ContainsKey(level))
        {
            return _dic_Level_CharacterLevel[level];
        }
        else
        {
            Debug.LogError($"Manager_Table::GetCharacterLevelInfo() - Level info not found for level: {level}");
            return null;
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="level"></param>
    /// <returns></returns>
    public _108_PlayerLevel.Values GetPlayerLevelInfo(int level)
    {
        if (_dic_Level_PlayerLevel.ContainsKey(level))
        {
            return _dic_Level_PlayerLevel[level];
        }
        else
        {
            Debug.LogError($"Manager_Table::GetPlayerLevelInfo() - Level info not found for level: {level}");
            return null;
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="level"></param>
    /// <returns></returns>
    public _111_WeaponLevel.Values GetWeaponLevelInfo(int level)
    {
        if (_dic_Level_WeaponLevel.ContainsKey(level))
        {
            return _dic_Level_WeaponLevel[level];
        }
        else
        {
            Debug.LogError($"Manager_Table::GetWeaponLevelInfo() - Level info not found for level: {level}");
            return null;
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="level"></param>
    /// <returns></returns>
    public _112_ArmorLevel.Values GetArmorLevelInfo(int level)
    {
        if (_dic_Level_ArmorLevel.ContainsKey(level))
        {
            return _dic_Level_ArmorLevel[level];
        }
        else
        {
            Debug.LogError($"Manager_Table::GetArmorLevelInfo() - Level info not found for level: {level}");
            return null;
        }
    }
}
